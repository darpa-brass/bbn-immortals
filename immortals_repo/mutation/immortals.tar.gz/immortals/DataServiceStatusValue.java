DataServiceStatusValue
~~~
value
~~~
fromValue
