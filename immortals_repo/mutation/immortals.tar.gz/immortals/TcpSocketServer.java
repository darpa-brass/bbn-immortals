TcpSocketServer
~~~
startListeningForClients
~~~
getName
~~~
startListening
~
log.debug("starting thread to listen on " + this);
~
srv.setName("TCPServer:" + serverSocket.getLocalPort());
~~~
startListening
~
log.debug("starting thread to listen on " + this);
~
srv.setName("TCPServer:" + serverSocket.getLocalPort());
~~~
toString
~~~
getPort
~~~
handleData
~~~
close
~
serverSocket.close();
~
remoteDisconnected.consume(null);
~
System.err.println("Error closing server socket. Transport: " + transport.toString());
~
try {
    serverSocket.close();
    remoteDisconnected.consume(null);
} catch (IOException e) {
    System.err.println("Error closing server socket. Transport: " + transport.toString());
}
~
if (serverSocket != null) {
    try {
        serverSocket.close();
        remoteDisconnected.consume(null);
    } catch (IOException e) {
        System.err.println("Error closing server socket. Transport: " + transport.toString());
    }
}
~~~
getLocalPort
~~~
setOutputClientConnectedListener
