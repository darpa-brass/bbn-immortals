ImageFormattingFilter
~~~
filter
~~~
filter
