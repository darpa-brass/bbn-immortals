Util
~~~
generateUid
~~~
sleepMillis
~
Thread.sleep(millis);
~
log.warn("Thread sleep interrupted", e);
~
try {
    Thread.sleep(millis);
} catch (InterruptedException e) {
    log.warn("Thread sleep interrupted", e);
}
~~~
sleepSecs
~
sleepMillis(seconds * 1000);
~~~
parseCotEndpoint
~
String[] tokens = endpoint.split(":");
~
if (tokens.length < 3) {
    log.error("Malformed subscription endpoint: " + endpoint);
    return null;
}
~
try {
    // Try option #1
    ret.port = Integer.parseInt(tokens[2]);
    ret.address = tokens[1];
    ret.protocol = tokens[0];
} catch (NumberFormatException e) {
    try {
        // Try option #2
        ret.port = Integer.parseInt(tokens[1]);
        ret.address = tokens[0];
        ret.protocol = tokens[2];
    } catch (NumberFormatException nfe) {
        // Both failed!
        return null;
    }
}
