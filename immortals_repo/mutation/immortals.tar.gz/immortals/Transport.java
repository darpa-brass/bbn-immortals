Transport
~~~
handleData
~~~
getName
~~~
close
~~~
receiveFromNetworkPipe
~~~
sendToNetworkPipe
~~~
setEndpoint
~
this.port = port;
~~~
getLocalPort
~~~
connect
~
throw new IOException("must set endpoint prior to connection.");
~
if (host == null || port < 0) {
    throw new IOException("must set endpoint prior to connection.");
}
~~~
startListening
~~~
dataReceived
~
receiveFromNetworkPipe.consume(Arrays.copyOf(received, bytesRead));
~~~
getHost
~~~
getPort
~~~
toString
~~~
setReceiveFromNetworkPipeListener
~
this.receiveFromNetworkPipe = next;
~~~
setRemoteDisconnectedListener
~
this.remoteDisconnected = next;
