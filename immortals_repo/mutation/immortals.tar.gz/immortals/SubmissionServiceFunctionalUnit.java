SubmissionServiceFunctionalUnit
~~~
addCotClientToService
~~~
addCotServerChannelToService
~~~
sendCotDataToService
