BitmapScaler
~~~
consume
~
BufferedImage output = ImageUtilsJava.scaleBitmap(input, scalingValue);
~
next.consume(output);
~~~
flushPipe
~
next.flushPipe();
~~~
closePipe
~
next.closePipe();
