TcpTransportToCotChannelData
~~~
process
~
// Connect then network connection to the buffer
tt.setReceiveFromNetworkPipeListener(// Connect then network connection to the buffer
new CotByteBufferPipe(// Connect the buffer to the server
channel.sendCotFromRemoteToLocal(), // And connect it to the BitmapWriter
new CotEventImageExtractor(new BitmapWriter(Paths.get(MartiMain.getConfig().storageDirectory), new ConsumingPipe<Path>() {

    @Override
    public void consume(Path path) {
        logger.info("Wrote image to '" + path.toString() + "'.");
    }

    @Override
    public void flushPipe() {
    }

    @Override
    public void closePipe() {
    }
}))));
~
// Connect the disconnection notification
tt.setRemoteDisconnectedListener(channel.remoteDisconnected());
~
channel.setServerCotProducerListener(new CotEventContainerBytesExtractionPipe(tt.sendToNetworkPipe()));
~
// Construct a CotChannel to provide the complete data for the new client to the server and distribute the result
return new CotChannelData(channel, tt.getHost(), tt.getName(), tt.getPort());
