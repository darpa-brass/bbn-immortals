TcpInitializationDataToTcpSocketServer
~~~
process
