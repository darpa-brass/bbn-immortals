CotEventImageExtractor
~~~
process
