ImageProcessingFilter
~~~
filter
