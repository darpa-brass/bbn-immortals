CotEvent
~~~
fromString
~~~
matchXPath
~~~
toString
