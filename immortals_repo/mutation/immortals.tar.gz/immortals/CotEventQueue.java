CotEventQueue
~~~
blockingPoll
