PrioritizedQueue
~~~
init
~~~
addItem
~
if (i.compareTo(qe) == 0) {
    // log.debug("Found a match for key: " + qe.key + "! Replacing.");
    i.element.set(qe.element.get());
    return true;
}
~
success = true;
~
for (QueueElement<E> i : this.prioQ.get(importance)) {
    if (i.compareTo(qe) == 0) {
        // log.debug("Found a match for key: " + qe.key + "! Replacing.");
        i.element.set(qe.element.get());
        return true;
    }
}
~
synchronized (this.prioQ.get(importance)) {
    for (QueueElement<E> i : this.prioQ.get(importance)) {
        if (i.compareTo(qe) == 0) {
            // log.debug("Found a match for key: " + qe.key + "! Replacing.");
            i.element.set(qe.element.get());
            return true;
        }
    }
}
~
this.queueMetrics[importance].currentSize.incrementAndGet();
~
synchronized (this.prioQ.get(importance)) {
    if (this.prioQ.get(importance).add(qe)) {
        // there are certain ways this could fail
        this.available.release();
        success = true;
    }
}
~
// no space left in queue...
log.error("Overfull queue for importance level: " + importance + "; " + this.getNumItems() + " items in queue; " + this.queueMetrics[importance].currentSize.get() + " elements out of " + this.queueMetrics[importance].capacity.get());
~
success = false;
~
// IMMORTALS
importance = 0;
~
if (replaceByPubUID) {
    synchronized (this.prioQ.get(importance)) {
        for (QueueElement<E> i : this.prioQ.get(importance)) {
            if (i.compareTo(qe) == 0) {
                // log.debug("Found a match for key: " + qe.key + "! Replacing.");
                i.element.set(qe.element.get());
                return true;
            }
        }
    }
}
~~~
destroy
~
prioQ.get(i).clear();
~
// log.error("Destroy called!");
this.available.drainPermits();
~
for (int i = 0; i < prioQ.size(); ++i) {
    prioQ.get(i).clear();
}
~
this.prioQ.clear();
~~~
getNextItemStrictPriority
~
this.queueMetrics[i].currentSize.addAndGet(-1);
~
break;
~
synchronized (prioQ.get(i)) {
    rval = prioQ.get(i).poll();
}
~
if (rval != null) {
    this.queueMetrics[i].currentSize.addAndGet(-1);
    break;
}
~~~
drain
~
// logic to keep the count accurate.
try {
    this.available.acquire();
    this.available.release();
} catch (InterruptedException ie) {
    return rval;
}
~
// Now pull everything out of the queue (up to maxNumber)
for (int i = 0; i < prioQ.size(); ++i) {
    synchronized (prioQ.get(i)) {
        QueueElement<E> next = null;
        while ((next = prioQ.get(i).poll()) != null) {
            rval.add(next.element.get());
            try {
                this.available.acquire();
            } catch (InterruptedException e) {
            }
            this.queueMetrics[i].currentSize.addAndGet(-1);
            if (maxNumber > 0 && rval.size() >= maxNumber)
                return rval;
        }
    }
}
~~~
drain
~
// logic to keep the count accurate.
try {
    this.available.acquire();
    this.available.release();
} catch (InterruptedException ie) {
    return rval;
}
~
// Now pull everything out of the queue (up to maxNumber)
for (int i = 0; i < prioQ.size(); ++i) {
    synchronized (prioQ.get(i)) {
        QueueElement<E> next = null;
        while ((next = prioQ.get(i).poll()) != null) {
            rval.add(next.element.get());
            try {
                this.available.acquire();
            } catch (InterruptedException e) {
            }
            this.queueMetrics[i].currentSize.addAndGet(-1);
            if (maxNumber > 0 && rval.size() >= maxNumber)
                return rval;
        }
    }
}
~~~
getNonemptyQueue
~
for (int i = startIndex; i < prioQ.size(); i++) {
    LinkedList<QueueElement<E>> finger = prioQ.get(i);
    synchronized (finger) {
        if (finger.size() > 0) {
            return i;
        }
    }
}
~~~
flipCoin
~~~
getNumItems
~~~
getNumItems
~~~
getNumImportanceLevels
~~~
queueStatus
~
for (int i = 0; i < prioQ.size(); ++i) {
    rval.append(this.prioQ.get(i).size());
    rval.append(", ");
}
~~~
getName
~~~
setName
~
this.name = name;
~~~
getQueueMetric
