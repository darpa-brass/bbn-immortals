ImageUtilsJava
~~~
resizeBitmap
~
double height = bmp.getHeight();
~
double width = bmp.getWidth();
~
double targetPixels = maxMegapixels * 1000000;
~
if ((height * width) > targetPixels) {
    double aspectRatio = height / width;
    int newHeight = (int) Math.floor(Math.sqrt(targetPixels * aspectRatio));
    int newWidth = (int) Math.floor(newHeight / aspectRatio);
    return resizeBitmap(bmp, newHeight, newWidth);
}
~~~
scaleBitmap
~
double height = bmp.getHeight();
~
double width = bmp.getWidth();
~
double totalPixels = height * width;
~
double totalPixelsPrime = height * width * scalingValue;
~
if (totalPixels > totalPixelsPrime) {
    double ratio = height / width;
    double widthPrime = Math.sqrt(totalPixelsPrime / ratio);
    double heightPrime = totalPixelsPrime / widthPrime;
    return resizeBitmap(bmp, (int) Math.floor(widthPrime), (int) Math.floor(heightPrime));
}
~~~
resizeBitmap
~
double height = bmp.getHeight();
~
double width = bmp.getWidth();
~
double targetPixels = maxMegapixels * 1000000;
~
if ((height * width) > targetPixels) {
    double aspectRatio = height / width;
    int newHeight = (int) Math.floor(Math.sqrt(targetPixels * aspectRatio));
    int newWidth = (int) Math.floor(newHeight / aspectRatio);
    return resizeBitmap(bmp, newHeight, newWidth);
}
