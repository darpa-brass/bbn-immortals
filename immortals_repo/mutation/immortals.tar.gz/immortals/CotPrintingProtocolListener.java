CotPrintingProtocolListener
~~~
onDataReceived
