CotByteBufferPipe
~~~
process
~
throw new RuntimeException(e);
~
try {
    cotList.add(new CotEventContainer(d));
} catch (DocumentException e) {
    throw new RuntimeException(e);
}
~
cot.setElevationData(elevationApi.getElevation(cot.getLon(), cot.getLat()));
~
distributeOutput(cot);
~~~
onClose
~
cotProc.removeBuilder(transport);
~~~
toString
