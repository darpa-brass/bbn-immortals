Assertion
~~~
condition
~
condition(toAssert, "");
~~~
condition
~
condition(toAssert, "");
~~~
fail
~
fail("");
~~~
fail
~
fail("");
~~~
notNull
~~~
notNull
~~~
isNull
~~~
zero
~~~
same
~
throw new AssertionException(String.format("Assertion.same failure: int 1 (%d) != int 2 (%d)", i1, i2));
~
if (i1 != i2) {
    throw new AssertionException(String.format("Assertion.same failure: int 1 (%d) != int 2 (%d)", i1, i2));
}
