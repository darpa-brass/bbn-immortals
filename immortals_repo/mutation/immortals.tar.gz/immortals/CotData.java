CotData
