TcpTransport
~~~
connect
~
// also check if bound? mjg
// informs listeners of onConnect()
connect(new Socket(host, port));
~
if (clientSocket == null || clientSocket.isClosed()) {
    // also check if bound? mjg
    // informs listeners of onConnect()
    connect(new Socket(host, port));
}
~~~
connect
~
// also check if bound? mjg
// informs listeners of onConnect()
connect(new Socket(host, port));
~
if (clientSocket == null || clientSocket.isClosed()) {
    // also check if bound? mjg
    // informs listeners of onConnect()
    connect(new Socket(host, port));
}
~~~
close
~
// close the socket
clientSocket.close();
~
// let go of pointer to the socket
clientSocket = null;
~
// Inform the listeners
remoteDisconnected.consume(null);
~
if (clientSocket != null) {
    // close the socket
    clientSocket.close();
    // let go of pointer to the socket
    clientSocket = null;
    // Inform the listeners
    remoteDisconnected.consume(null);
}
~
log.error("Error closing TcpTransport " + this + ": " + e.getMessage());
~
try {
    if (clientSocket != null) {
        // close the socket
        clientSocket.close();
        // let go of pointer to the socket
        clientSocket = null;
        // Inform the listeners
        remoteDisconnected.consume(null);
    }
} catch (IOException e) {
    log.error("Error closing TcpTransport " + this + ": " + e.getMessage());
}
~~~
handleData
~
if (clientSocket == null || !clientSocket.isConnected()) {
    // do nothing in the meantime
    return;
}
~
System.err.println("Error sendind data to " + this.toString());
~
// force a reconnect
clientSocket = null;
~~~
toString
~~~
setReceiveFromNetworkPipeListener
~~~
startListening
~~~
startListening
~~~
getLocalPort
