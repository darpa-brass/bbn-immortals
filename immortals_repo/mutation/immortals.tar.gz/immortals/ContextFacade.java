ContextFacade
~~~
lookupInteger
~~~
lookupString
~~~
lookup
