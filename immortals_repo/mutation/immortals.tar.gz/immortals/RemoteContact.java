RemoteContact
~~~
equals
~~~
hashCode
~~~
toString
