MonitorInterface
~~~
addCallback
