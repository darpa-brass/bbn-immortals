DataFerryManagerInterface
~~~
getFileList
~~~
getContactList
