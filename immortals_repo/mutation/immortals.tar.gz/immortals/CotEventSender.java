CotEventSender
~~~
addToOutputQueue
~~~
getChannel
~~~
sendNextElementOffQueue
~~~
run
~~~
stopThread
~
runThread.interrupt();
~
keepgoing.set(false);
~
if (this.runThread != null) {
    runThread.interrupt();
}
~
synchronized (this) {
    keepgoing.set(false);
    if (this.runThread != null) {
        runThread.interrupt();
    }
}
~~~
sleepUntilNext
~
// System.err.println("Warning, sending too slow!  Bandwidth must be lower than expected.");
return;
~
nextTimeMs -= deltaMs;
~
// the new bandwidth is higher than our old one, and we can send immediately
return;
~
return;
~
nextTimeMs = ((1000 * messageSize * 8) / 1024) / oldBw;
~
if (deltaMs >= nextTimeMs) {
    // System.err.println("Warning, sending too slow!  Bandwidth must be lower than expected.");
    return;
} else {
    nextTimeMs -= deltaMs;
}
~
nextTimeMs = 0;
~
System.err.println("Warning: zero bandwidth available.  Waiting for update...");
~
// System.err.println("bw: " + oldBw);
// System.err.println("Sleeping " + nextTimeMs + "ms for message of size: " + (messageSize* 8) / 1024 + " kbits");
this.wait(nextTimeMs);
~
long remainingTime = nextTimeAbs - System.currentTimeMillis();
~
long nextSize = (remainingTime * oldBw * 1024) / 8 / 1000;
~
// System.err.println("Interupted sleep! old size: " + (messageSize* 8) / 1024 + ", new size: " + (nextSize* 8) / 1024);
if (nextSize <= 0) {
    // the new bandwidth is higher than our old one, and we can send immediately
    return;
}
~
sleepUntilNext(nextSize, 0);
~
long oldBw = availBwKbps.get();
~
long nextTimeMs;
~
if (oldBw == UNLIMITED_BW) {
    return;
}
~
if (oldBw != 0) {
    nextTimeMs = ((1000 * messageSize * 8) / 1024) / oldBw;
    if (deltaMs >= nextTimeMs) {
        // System.err.println("Warning, sending too slow!  Bandwidth must be lower than expected.");
        return;
    } else {
        nextTimeMs -= deltaMs;
    }
} else {
    nextTimeMs = 0;
    System.err.println("Warning: zero bandwidth available.  Waiting for update...");
}
~
long nextTimeAbs = System.currentTimeMillis() + nextTimeMs;
~
try {
    // System.err.println("bw: " + oldBw);
    // System.err.println("Sleeping " + nextTimeMs + "ms for message of size: " + (messageSize* 8) / 1024 + " kbits");
    this.wait(nextTimeMs);
} catch (InterruptedException e) {
    long remainingTime = nextTimeAbs - System.currentTimeMillis();
    long nextSize = (remainingTime * oldBw * 1024) / 8 / 1000;
    // System.err.println("Interupted sleep! old size: " + (messageSize* 8) / 1024 + ", new size: " + (nextSize* 8) / 1024);
    if (nextSize <= 0) {
        // the new bandwidth is higher than our old one, and we can send immediately
        return;
    }
    sleepUntilNext(nextSize, 0);
}
~~~
getAndResetPeriodicBytes
~
this.periodicOutputInBytes.set(0);
~~~
getBandwidthLimitKbps
~~~
setBandwidthLimitKbps
~
availBwKbps.set(v);
~~~
queueSize
