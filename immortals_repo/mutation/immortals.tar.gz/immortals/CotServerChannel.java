CotServerChannel
~~~
clientConnected
~~~
getStartListening
~~~
setStartListeningListener
