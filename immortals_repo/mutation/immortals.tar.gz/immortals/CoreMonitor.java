CoreMonitor
~~~
getInstance
~~~
addCallback
