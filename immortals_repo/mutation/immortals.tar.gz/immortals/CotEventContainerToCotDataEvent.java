CotEventContainerToCotDataEvent
~~~
consume
~
Event e = CotHelper.unmarshalEvent(cotEventContainer.asXml());
~
throw new RuntimeException(e);
~
try {
    Event e = CotHelper.unmarshalEvent(cotEventContainer.asXml());
} catch (JAXBException e) {
    throw new RuntimeException(e);
}
~~~
flushPipe
~
next.flushPipe();
~~~
closePipe
~
next.closePipe();
