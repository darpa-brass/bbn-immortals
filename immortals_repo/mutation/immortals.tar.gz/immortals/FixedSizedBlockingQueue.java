FixedSizedBlockingQueue
~~~
setSizeLimit
~~~
add
~
// we incremented atomically, but aren't adding, so put the counter back where it was
queueMetric.currentSize.decrementAndGet();
~~~
take
~
queueMetric.currentSize.decrementAndGet();
~~~
take
~
queueMetric.currentSize.decrementAndGet();
~~~
getQueueMetrics
