CotDbInsertionPipe
~~~
consume
~
Event e = CotHelper.unmarshalEvent(input.asXml());
~
cotDbConsumer.consume(e);
~
throw new RuntimeException(e);
~
try {
    Event e = CotHelper.unmarshalEvent(input.asXml());
    cotDbConsumer.consume(e);
} catch (JAXBException e) {
    throw new RuntimeException(e);
}
~
if (cotDbConsumer != null) {
    try {
        Event e = CotHelper.unmarshalEvent(input.asXml());
        cotDbConsumer.consume(e);
    } catch (JAXBException e) {
        throw new RuntimeException(e);
    }
}
~
next.consume(input);
~~~
flushPipe
~~~
closePipe
