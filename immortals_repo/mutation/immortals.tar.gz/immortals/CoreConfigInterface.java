CoreConfigInterface
~~~
getAttributeMap
~~~
setAttributeRemote
~~~
getAttributeRemote
