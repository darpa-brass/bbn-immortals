SocketToTcpTransport
~~~
process
