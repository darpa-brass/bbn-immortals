BitmapReader
~~~
consume
~
throw new RuntimeException(e);
~~~
flushPipe
~
next.flushPipe();
~~~
closePipe
~
next.closePipe();
