Endpoints
~~~
test
~~~
shutdown
~~~
cotEventsForConstantCotType
