QueryResultStatusValue
~~~
value
~~~
fromValue
