BitmapDownsizer
~~~
consume
~
BufferedImage output = ImageUtilsJava.resizeBitmap(input, targetMegapixels);
~
next.consume(output);
~~~
flushPipe
~
next.flushPipe();
~~~
closePipe
~
next.closePipe();
