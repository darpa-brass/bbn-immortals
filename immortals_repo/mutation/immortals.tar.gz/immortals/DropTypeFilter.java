DropTypeFilter
~~~
filter
