TcpSocketServerToCotServerChannel
~~~
process
