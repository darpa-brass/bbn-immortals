BitmapWriter
~~~
process
~
throw new RuntimeException(e);
