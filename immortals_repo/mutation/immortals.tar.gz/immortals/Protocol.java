Protocol
~~~
sendingCotData
